﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FavRestaurants.Models
{
    public class SuggestionResponse
    {
        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Restaurant name is required")]
        public string RestName { get; set; }
        public string FavDish { get; set; }
        [Required(ErrorMessage = "Phone number is required")]
        [RegularExpression("^\\D?(\\d{3})\\D?\\D?(\\d{3})\\D?(\\d{4})$", ErrorMessage = "Please enter valid phone number")]
        public string RestPhone { get; set; }
    }
}
