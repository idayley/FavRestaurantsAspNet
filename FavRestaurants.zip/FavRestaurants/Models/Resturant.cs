﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FavRestaurants.Models
{
    // Class for storing the top restaurants
    public class Restaurant
    {
        public int RestRanking { get; } 
        public string Restname { get; set; }
        public string? FavDish { get; set; }  // Null set in controller
        public string Address { get; set; }
        public string? RestPhone { get; set; } // Null set in controller
        public string? WebLink { get; set; } = "Coming Soon.";

        public Restaurant(int rank)
        {
            RestRanking = rank;
        }


        public static Restaurant[] GetRests()
        {
            // Hard code the top 5 restaurants
            Restaurant r1 = new Restaurant(1)
            {
                Restname = "Black Sheep Cafe", 
                FavDish = "Black Sheep Burger",
                Address = "19 N University Ave, Provo, UT 84601-4429", 
                RestPhone = "801-607-2485", 
                WebLink = "https://www.blacksheepcafe.com/"
            };

            Restaurant r2 = new Restaurant(2)
            {
                Restname = "Tucanos Brazilian Grill",
                Address = "545 E University Pkwy, Provo, UT 84097",
                RestPhone = "801-224-4774",
                WebLink = "http://www.tucanos.com/orem.html"
            };

            Restaurant r3 = new Restaurant(3)
            {
                Restname = "Costa Vida",
                Address = "1200 N University Provo, UT 84606",
                RestPhone = "801-373-1876",
                WebLink = "https://www.costavida.com/locations/ut/provo"
            };

            Restaurant r4 = new Restaurant(4)
            {
                Restname = "Chip Cookies",
                FavDish = "Chocolate Chip Cookie",
                Address = "470 n freedom blvd provo, UT 84111",
                RestPhone = "801-607-2485",
                WebLink = "https://www.chipcookies.co/"
            };

            Restaurant r5 = new Restaurant(5)
            {
                Restname = "Mooyah",
                Address = "62 W 1230 North Suite 105 Provo, UT 84604",
                RestPhone = null,
                //WebLink = "https://www.mooyah.com/locations/provo-ut-285"
            };



            return new Restaurant[] { r1, r2, r3, r4, r5 };
        }
    }
}
