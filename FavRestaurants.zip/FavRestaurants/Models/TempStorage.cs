﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FavRestaurants.Models
{
    // Temporarily store the models
    public class TempStorage
    {
        private static List<SuggestionResponse> responses = new List<SuggestionResponse>();

        public static IEnumerable<SuggestionResponse> Responses => responses;

        public static void AddApplication(SuggestionResponse response)
        {
            responses.Add(response);
        }
    }
}
