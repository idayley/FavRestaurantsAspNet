﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FavRestaurants.Models;

namespace FavRestaurants.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Index()
        {
            List<string> restList = new List<string>();

            foreach (Restaurant r in Restaurant.GetRests())
            {
                // Catch null values to prevent from breaking
                string? phone = r.RestPhone ?? "000-000-0000";
                string? FavoriteDish = r.FavDish ?? "It's all tasty!";
                restList.Add($"#{r.RestRanking}: {r.Restname} {FavoriteDish} {r.Address} {phone} {r.WebLink}");
            }

            return View(restList);
        }

        [HttpGet]
        public IActionResult SubmitSuggestion()
        {
            return View();
        }

        // When the view is called from a post request
        [HttpPost]
        public IActionResult SubmitSuggestion(SuggestionResponse suggResponse)
        {
            //check to ensure that the model is valid, if not send back to the view without storing
            if (ModelState.IsValid)
            {
                TempStorage.AddApplication(suggResponse);
                return View("Confirmation", suggResponse);
            }
            return View();
            
        }

        public IActionResult SuggestionList()
        {
            return View(TempStorage.Responses);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
